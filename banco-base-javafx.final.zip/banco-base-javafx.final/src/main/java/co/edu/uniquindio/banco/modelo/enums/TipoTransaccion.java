package co.edu.uniquindio.banco.modelo.enums;

public enum TipoTransaccion {
    DEPOSITO, RETIRO
}
