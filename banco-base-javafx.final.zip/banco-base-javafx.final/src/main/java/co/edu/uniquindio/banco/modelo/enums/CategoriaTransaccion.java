package co.edu.uniquindio.banco.modelo.enums;

public enum CategoriaTransaccion {
    VIAJES, FACTURAS, GASOLINA, ROPA, PAGO, OTROS
}
